ALTER TABLE users
  ADD COLUMN latitude double precision,
  ADD COLUMN longitude double precision;
