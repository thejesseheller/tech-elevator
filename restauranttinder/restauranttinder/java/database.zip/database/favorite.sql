ALTER TABLE users
  ADD COLUMN zip_code varChar(10),
  ADD COLUMN address varChar(32),
  ADD COLUMN city varChar(32),
  ADD COLUMN state varChar(4);
  