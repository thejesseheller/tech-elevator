ALTER TABLE users
DROP column address,
DROP column city,
DROP column state;